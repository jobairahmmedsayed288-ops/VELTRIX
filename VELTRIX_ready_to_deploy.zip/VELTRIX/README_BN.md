# VELTRIX

**Your Business. Your Control.** — তোমার ব্যবসা, তোমার নিয়ন্ত্রণ।

এটি VELTRIX-এর আসল full-stack web app source project (শুধু এক ফাইলের browser demo নয়)। এতে React frontend, Supabase Auth/Database সংযোগ, পণ্য-ভ্যারিয়েন্ট স্টক, বিক্রি, খরচ, ড্যাশবোর্ড এবং database Row Level Security schema আছে।

## এই সংস্করণে যা আছে
- মোবাইল/ডেস্কটপ responsive interface
- ফোন নম্বর + পাসওয়ার্ড লগইন/অ্যাকাউন্ট তৈরি (Supabase Auth সেটিংস প্রয়োজন)
- ডিজাইন কোড + রং + সাইজ অনুযায়ী স্টক
- একই design/color/size পুনরায় যোগ করলে একই স্টকের পরিমাণ বাড়ানো
- বিক্রি রেকর্ড এবং ডেটাবেস trigger দিয়ে স্টক কমানো
- খরচ ও বিক্রির সারাংশ
- নিজের ডেটা অন্য user থেকে আলাদা রাখতে RLS policy

## চালানোর জন্য প্রয়োজনীয়
1. Supabase-এ একটি project তৈরি করে SQL Editor-এ `supabase/schema.sql` চালাতে হবে।
2. Authentication settings-এ Phone ও Password চালু করতে হবে। OTP চাইলে SMS provider configure করতে হবে।
3. `.env.example` কপি করে `.env` বানিয়ে Supabase URL ও anon key বসাতে হবে।
4. `npm install` তারপর `npm run dev` চালাতে হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা — গোপন করিনি
- এই source package নিজে থেকে ইন্টারনেটে প্রকাশিত হয় না। অনলাইনে চালাতে একটি managed backend এবং web hosting-এ deploy করতে হবে।
- সদস্য invite/role permission UI এখনো সম্পূর্ণ হয়নি। এই build-এ নিরাপদ personal-owner access আছে; member invitation চালু করার আগে membership table, approval flow ও RLS policy যোগ করা বাধ্যতামূলক।
- SMS OTP provider সেটআপ ছাড়া SMS verification কাজ করবে না।
- প্রথম account-কে owner করা হয়েছে; account creation public রাখা production-এর জন্য উপযুক্ত নয়। প্রথম owner account তৈরি হওয়ার পর Supabase Auth-এর public sign-up বন্ধ/সীমিত করতে হবে।
- ডেটাবেসে sale transaction stock কমায়, তবে frontend-এ sale creation-এর জন্য RPC transaction flow আরও শক্ত করা উচিত; production launch-এর আগে পরীক্ষা আবশ্যক।

## Production launch
এটি deployable application source; এখনো কোনো live URL বা hosting-এ প্রকাশ করা হয়নি। Supabase project credentials এবং hosting deployment ছাড়া অ্যাপটি অন্য ফোনে অনলাইনে sync করবে না।


## ফোনে ইনস্টল (PWA)
প্রজেক্টটি HTTPS hosting-এ প্রকাশিত হলে Android Chrome-এ URL খুলে browser menu থেকে **Install app** বা **Add to Home screen** চাপলে VELTRIX ফোনে ইনস্টল হবে। Service worker app shell cache করে; তবে ডেটা সিঙ্ক ও লগইনের জন্য ইন্টারনেট এবং Supabase backend লাগবে।
