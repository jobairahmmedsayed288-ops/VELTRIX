-- VELTRIX database schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'member' check (role in ('owner','admin','member')),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  design_code text not null,
  color text not null,
  size text not null,
  quantity integer not null default 0 check (quantity >= 0),
  cost_price numeric(12,2) not null default 0 check(cost_price >= 0),
  selling_price numeric(12,2) not null default 0 check(selling_price >= 0),
  created_at timestamptz not null default now(),
  unique(owner_id,design_code,color,size)
);
create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  design_code text not null,
  color text not null,
  size text not null,
  quantity integer not null check(quantity > 0),
  total_amount numeric(12,2) not null check(total_amount >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null,
  amount numeric(12,2) not null check(amount >= 0),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,role,approved)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),'owner',true)
  on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.record_sale_and_reduce_stock()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  update public.products
  set quantity=quantity-new.quantity
  where id=new.product_id and owner_id=new.owner_id and quantity>=new.quantity;
  if not found then raise exception 'Insufficient stock or product not found'; end if;
  return new;
end; $$;
drop trigger if exists sales_reduce_stock on public.sales;
create trigger sales_reduce_stock before insert on public.sales
for each row execute function public.record_sale_and_reduce_stock();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;

-- Personal-owner baseline: users can access only their own records.
create policy "profile read own" on public.profiles for select to authenticated using(id=auth.uid());
create policy "profile update own name" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "products own all" on public.products for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy "sales own all" on public.sales for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy "expenses own all" on public.expenses for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());

-- IMPORTANT: Enable Phone + Password in Supabase Auth settings.
-- Configure an SMS provider before expecting phone OTP verification.
-- For invited multi-user access, add an owner-controlled membership/invitation table
-- and stricter role policies before enabling member invitations in production.
